package com.operations;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpInsert {

	public static void main(String[] args) {
		 
		Configuration cfg = new Configuration();
		
		cfg.configure();
		
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory factory = cfg.buildSessionFactory();
		
	    Session session = factory.openSession();
	    
	    Transaction transaction = session.beginTransaction();
	    
	    Employee e1 = new Employee(5,"John","tester","john12@gmail.com",34000,45,30);
	   
	    session.save(e1);
	    
	    transaction.commit();
	    
	    System.out.println(e1);
	    
	    System.out.println("Data Inserted Successfully");
	}
}
