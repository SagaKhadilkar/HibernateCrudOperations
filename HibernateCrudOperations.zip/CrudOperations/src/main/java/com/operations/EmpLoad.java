package com.operations;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpLoad {

	public static void main(String[] args) {
		 
		Configuration cfg = new Configuration();
		
		cfg.configure();
		
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory factory = cfg.buildSessionFactory();
		
	    Session session = factory.openSession();
	    
	    Transaction transaction = session.beginTransaction();
	    
	    Employee e1 = session.load(Employee.class,3);;
	    
	    transaction.commit();
	    
	    System.out.println(e1);
	    
	    System.out.println("Data Load Successfully");
	}
}
