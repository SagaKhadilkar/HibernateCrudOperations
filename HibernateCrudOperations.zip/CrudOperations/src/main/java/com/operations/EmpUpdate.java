package com.operations;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpUpdate {

	public static void main(String[] args) {
		 
		Configuration cfg = new Configuration();
		
		cfg.configure();
		
		cfg.addAnnotatedClass(Employee.class);
		
		SessionFactory factory = cfg.buildSessionFactory();
		
	    Session session = factory.openSession();
	    
	    Transaction transaction = session.beginTransaction();
	    
	    Employee e1 = new Employee(2,"Elan","Hr","elen32@gmail.com",25000,35,15);
	   
	    session.update(e1);
	    
	    transaction.commit();
	    
	    System.out.println(e1);
	    
	    System.out.println("Data Updated Successfully");
	}
}
